INAYATULLAH I.S.I.E SOLAR ENERGY — Free bilingual website

FILES
- index.html: the complete responsive website (English + Urdu language toggle)

BEFORE PUBLISHING
1. Open index.html in a browser and test the Urdu/English toggle.
2. Confirm phone number and business details.
3. Add your real project photos and service area when available.
4. This is a static website; it does not collect customer data or require a paid backend.

FREE HOSTING OPTION (GitHub Pages)
1. Create/sign in to a GitHub account.
2. Create a new public repository, e.g. isie-solar-website.
3. Upload index.html to the repository root.
4. In repository Settings → Pages, choose deploy from branch, select main and /(root), then save.
5. GitHub will provide a free public website address after deployment.
You can later connect a custom domain if you buy one.

CONTACT LINKS
The site uses tel:+923700051426 and WhatsApp https://wa.me/923700051426 for the supplied number.
